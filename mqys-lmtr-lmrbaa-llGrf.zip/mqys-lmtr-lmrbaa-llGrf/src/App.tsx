import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Camera,
  Check,
  ChevronDown,
  Crosshair,
  Info,
  LockKeyhole,
  MousePointer2,
  RefreshCw,
  RotateCcw,
  Ruler,
  ScanLine,
  ShieldCheck,
  Target,
  X,
} from 'lucide-react';

type Point = { id: number; x: number; y: number; px: number; py: number };
type CameraError = 'unsupported' | 'denied' | 'unknown';

const INITIAL_SCALE = 110;

function distance(a: Point, b: Point) {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
}

function polygonArea(points: Point[]) {
  if (points.length < 3) return 0;
  return Math.abs(
    points.reduce((sum, point, index) => {
      const next = points[(index + 1) % points.length];
      return sum + point.x * next.y - next.x * point.y;
    }, 0) / 2,
  );
}

function meters(value: number) {
  return value.toLocaleString('ar-SA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function App() {
  const [isActive, setIsActive] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [cameraError, setCameraError] = useState<CameraError | null>(null);
  const [points, setPoints] = useState<Point[]>([]);
  const [isClosed, setIsClosed] = useState(false);
  const [scale, setScale] = useState(INITIAL_SCALE);
  const [isArMode, setIsArMode] = useState(false);
  const [showAccuracy, setShowAccuracy] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [showScale, setShowScale] = useState(false);
  const [streamVersion, setStreamVersion] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const xrSessionRef = useRef<any>(null);

  const area = useMemo(() => polygonArea(points), [points]);
  const perimeter = useMemo(
    () => points.reduce((sum, point, index) => (index ? sum + distance(points[index - 1], point) : sum), 0),
    [points],
  );

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    if (xrSessionRef.current) {
      void xrSessionRef.current.end().catch(() => undefined);
      xrSessionRef.current = null;
    }
  }, []);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const detectAR = useCallback(async () => {
    const xr = (navigator as Navigator & { xr?: any }).xr;
    if (!xr?.isSessionSupported) return false;
    try {
      const supported = await xr.isSessionSupported('immersive-ar');
      if (!supported || !xr.requestSession) return false;
      const session = await xr.requestSession('immersive-ar', {
        requiredFeatures: ['hit-test', 'local-floor'],
      });
      xrSessionRef.current = session;
      session.addEventListener('end', () => {
        xrSessionRef.current = null;
        setIsArMode(false);
      });
      return true;
    } catch {
      return false;
    }
  }, []);

  const startCamera = useCallback(async () => {
    setIsStarting(true);
    setCameraError(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError('unsupported');
      setIsStarting(false);
      return;
    }
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } },
      });
      streamRef.current = mediaStream;
      setIsActive(true);
      setStreamVersion((version) => version + 1);
      const arReady = await detectAR();
      setIsArMode(arReady);
    } catch (error) {
      const name = error instanceof DOMException ? error.name : '';
      setCameraError(name === 'NotAllowedError' || name === 'SecurityError' ? 'denied' : 'unknown');
    } finally {
      setIsStarting(false);
    }
  }, [detectAR]);

  useEffect(() => {
    if (isActive && videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
      void videoRef.current.play().catch(() => undefined);
    }
  }, [isActive, streamVersion]);

  const resetMeasurement = useCallback(() => {
    setPoints([]);
    setIsClosed(false);
    setShowReset(false);
  }, []);

  const handleStagePointer = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!isActive || isClosed || isStarting) return;
    if ((event.target as HTMLElement).closest('button')) return;
    const stage = stageRef.current;
    if (!stage) return;
    const bounds = stage.getBoundingClientRect();
    const px = event.clientX - bounds.left;
    const py = event.clientY - bounds.top;
    if (px < 14 || py < 14 || px > bounds.width - 14 || py > bounds.height - 14) return;
    stage.setPointerCapture?.(event.pointerId);
    setPoints((current) => [
      ...current,
      {
        id: Date.now() + current.length,
        px,
        py,
        x: (px - bounds.width / 2) / scale,
        y: (py - bounds.height / 2) / scale,
      },
    ]);
  };

  const closePolygon = () => {
    if (points.length >= 3) setIsClosed(true);
  };

  const errorCopy: Record<CameraError, { title: string; body: string }> = {
    unsupported: {
      title: 'الكاميرا غير متاحة في هذا المتصفح',
      body: 'جرّب فتح مقياس في Safari أو Chrome عبر اتصال آمن، أو استخدم جهازاً يدعم الكاميرا.',
    },
    denied: {
      title: 'لم نتمكن من الوصول إلى الكاميرا',
      body: 'اسمح بالوصول إلى الكاميرا من إعدادات المتصفح، ثم حاول مرة أخرى. لا نرسل أي صورة إلى الخارج.',
    },
    unknown: {
      title: 'حدث عائق أثناء تشغيل الكاميرا',
      body: 'تحقق من أن الكاميرا ليست قيد الاستخدام في تطبيق آخر ثم أعد المحاولة.',
    },
  };

  return (
    <main className="room-page" dir="rtl">
      <div className="mx-auto flex min-h-[100dvh] w-full max-w-[1520px] flex-col px-4 py-4 sm:px-6 lg:px-10 lg:py-7">
        <header className="room-rise flex items-center justify-between gap-4 pb-5">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#142528] text-[#d9f0d9] shadow-[0_8px_20px_rgba(20,37,40,.16)]">
              <Crosshair size={22} strokeWidth={1.7} />
            </div>
            <div>
              <div className="font-[var(--app-font-serif)] text-[17px] font-semibold tracking-[-.04em] text-[#142528]">مِقياس</div>
              <div className="text-[11px] font-medium tracking-[.02em] text-[#5e7776]">أداة قياس المكان</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-full border border-[#cbdcd4] bg-[#f8f7f1]/80 px-3 py-2 text-[11px] font-medium text-[#49615f] sm:flex">
              <ShieldCheck size={14} className="text-[#0b7c78]" />
              <span>خصوصيتك أولاً</span>
            </div>
            {isActive && (
              <button
                type="button"
                onClick={() => setShowReset(true)}
                data-testid="button-reset-header"
                className="control-button inline-flex items-center gap-2 rounded-full border border-[#cbdcd4] bg-[#f8f7f1]/80 px-3 py-2 text-xs font-semibold text-[#49615f] hover:bg-[#fffdf7]"
              >
                <RotateCcw size={14} />
                <span className="hidden sm:inline">قياس جديد</span>
              </button>
            )}
          </div>
        </header>

        <div className="grid flex-1 items-center gap-5 lg:grid-cols-[minmax(0,1fr)_375px] xl:gap-8">
          <section className="room-rise room-delay-1 order-1 flex min-h-0 flex-col">
            <div
              ref={stageRef}
              onPointerDown={handleStagePointer}
              data-testid="camera-stage"
              className="camera-stage relative min-h-[55vh] flex-1 overflow-hidden rounded-[28px] sm:min-h-[620px] lg:min-h-[min(74vh,760px)]"
            >
              {isActive && streamRef.current ? (
                <video
                  ref={videoRef}
                  key={streamVersion}
                  autoPlay
                  muted
                  playsInline
                  aria-label="بث الكاميرا المباشر"
                  className="absolute inset-0 h-full w-full"
                  data-testid="video-camera"
                />
              ) : (
                <div className="absolute inset-0 overflow-hidden bg-[radial-gradient(ellipse_at_48%_80%,#b8a897_0%,#71817c_33%,#26494a_75%,#173538_100%)]">
                  <div className="absolute bottom-[-9%] left-[-10%] h-[56%] w-[120%] rotate-[-3deg] bg-[#aa9a8b]/65 [clip-path:polygon(0_25%,100%_0,100%_100%,0_100%)]" />
                  <div className="absolute bottom-[8%] right-[7%] h-[44%] w-[34%] rounded-t-[50%] bg-[#d8cdb9]/35 blur-[1px]" />
                  <div className="absolute left-[13%] top-[10%] h-[32%] w-[27%] border-[12px] border-[#d7e0d3]/15 bg-[#a8b8ae]/10" />
                  <div className="absolute bottom-0 left-0 h-1/3 w-full bg-gradient-to-t from-[#142d30]/35 to-transparent" />
                </div>
              )}
              <div className="camera-grid pointer-events-none absolute inset-0 z-[1]" />
              {isActive && <div className="camera-scanline" />}

              <div className="absolute inset-x-4 top-4 z-10 flex items-start justify-between gap-3 sm:inset-x-6 sm:top-6">
                <div className="flex items-center gap-2 rounded-full border border-white/15 bg-[#142528]/65 px-3 py-2 text-[11px] font-medium text-[#f2f1df] backdrop-blur-md">
                  <span className={`h-2 w-2 rounded-full ${isActive ? 'bg-[#8ce0b9]' : 'bg-[#f1a18e]'}`} />
                  <span data-testid="status-camera-mode">{isActive ? (isArMode ? 'وضع الواقع المعزز' : 'وضع الكاميرا اليدوي') : 'المعاينة'}</span>
                </div>
                <div className="flex gap-2">
                  {isActive && (
                    <button type="button" onClick={() => setShowScale((value) => !value)} data-testid="button-toggle-scale" className="control-button grid h-9 w-9 place-items-center rounded-full border border-white/15 bg-[#142528]/65 text-[#e6f0df] backdrop-blur-md" aria-label="فتح ضبط المقياس">
                      <Ruler size={16} />
                    </button>
                  )}
                  <button type="button" onClick={() => setShowAccuracy((value) => !value)} data-testid="button-toggle-accuracy" className="control-button grid h-9 w-9 place-items-center rounded-full border border-white/15 bg-[#142528]/65 text-[#e6f0df] backdrop-blur-md" aria-label="معلومات الدقة">
                    <Info size={16} />
                  </button>
                </div>
              </div>

              {showAccuracy && (
                <div className="absolute right-4 top-[4.7rem] z-20 max-w-[260px] rounded-2xl border border-[#dce7db]/25 bg-[#142528]/90 p-3 text-right text-[11px] leading-6 text-[#e4f0df] shadow-2xl backdrop-blur-md sm:right-6">
                  <div className="mb-1 flex items-center gap-2 font-semibold text-[#a9e4bd]"><ShieldCheck size={14} /> ملاحظة الدقة</div>
                  <p className="m-0 text-[#d6e2d9]">لأفضل نتيجة، التقط النقاط فوق مستوى الأرض مباشرة وعاير المقياس باستخدام بُعد تعرفه.</p>
                </div>
              )}

              {showScale && isActive && (
                <div className="absolute left-4 top-[4.7rem] z-20 w-[230px] rounded-2xl border border-[#dce7db]/25 bg-[#142528]/90 p-3 text-right text-[11px] leading-5 text-[#e4f0df] shadow-2xl backdrop-blur-md sm:left-6">
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <span className="font-semibold text-[#a9e4bd]">معايرة العرض</span>
                    <span className="font-mono text-[#f1a18e]">{scale} بكسل/م</span>
                  </div>
                  <input type="range" min="60" max="220" value={scale} onChange={(event) => setScale(Number(event.target.value))} data-testid="input-scale-overlay" aria-label="مقياس البكسل لكل متر" className="range-instrument h-5 w-full cursor-pointer" />
                  <p className="mt-1.5 mb-0 text-[#c4d6ca]">حرّك المؤشر حتى يتطابق طول معروف مع الشاشة.</p>
                </div>
              )}

              {!isActive && !cameraError && (
                <div className="absolute inset-0 z-10 flex items-center justify-center p-6">
                  <div className="max-w-sm text-center text-[#f2f1df]">
                    <div className="target-pulse mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full border border-[#b8e6c4]/40 bg-[#142528]/55 text-[#b8e6c4] backdrop-blur-sm">
                      <ScanLine size={28} strokeWidth={1.5} />
                    </div>
                    <p className="mb-2 text-xs font-medium tracking-[.16em] text-[#b8e6c4]/75">جاهز للغرفة التالية</p>
                    <h2 className="font-[var(--app-font-serif)] text-2xl font-semibold leading-[1.6] sm:text-3xl">وجّه الكاميرا،<br />وابدأ من زاوية.</h2>
                  </div>
                </div>
              )}

              {!isActive && cameraError && (
                <div className="absolute inset-0 z-10 flex items-center justify-center p-6">
                  <div className="max-w-sm rounded-3xl border border-[#f2c0af]/25 bg-[#142528]/85 p-6 text-center text-[#f2f1df] shadow-2xl backdrop-blur-md">
                    <div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-[#ef6f61]/15 text-[#f1a18e]"><AlertTriangle size={23} /></div>
                    <h2 className="mb-2 text-lg font-semibold">{errorCopy[cameraError].title}</h2>
                    <p className="mb-5 text-xs leading-6 text-[#d8e3da]">{errorCopy[cameraError].body}</p>
                    <button type="button" onClick={startCamera} data-testid="button-retry-camera" className="control-button inline-flex items-center gap-2 rounded-xl bg-[#f1a18e] px-4 py-2.5 text-xs font-bold text-[#142528]">
                      <RefreshCw size={14} /> إعادة المحاولة
                    </button>
                  </div>
                </div>
              )}

              {isActive && points.length === 0 && (
                <div className="manual-hint absolute inset-x-4 bottom-5 z-10 flex items-center justify-center gap-2 rounded-2xl border border-white/10 px-4 py-3 text-center text-xs text-[#edf1df] sm:inset-x-auto sm:right-1/2 sm:w-auto sm:translate-x-1/2">
                  <MousePointer2 size={15} className="shrink-0 text-[#a9e4bd]" />
                  <span>المس أول زاوية على الأرض لبدء المخطط</span>
                </div>
              )}

              {isActive && points.length > 0 && (
                <svg className="pointer-events-none absolute inset-0 z-[5] h-full w-full overflow-visible" aria-label="مخطط القياس">
                  {points.length > 1 && (
                    <polyline
                      points={points.map((point) => `${point.px},${point.py}`).join(' ')}
                      fill={isClosed ? 'rgba(140,224,185,.16)' : 'none'}
                      stroke="#a9e4bd"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeDasharray={isClosed ? undefined : '8 8'}
                      className={!isClosed ? 'measure-dash' : ''}
                    />
                  )}
                  {isClosed && points.length > 2 && (
                    <line x1={points.at(-1)?.px} y1={points.at(-1)?.py} x2={points[0].px} y2={points[0].py} stroke="#a9e4bd" strokeWidth="2.5" strokeLinecap="round" />
                  )}
                  {points.map((point, index) => {
                    const next = points[index + 1] ?? (isClosed ? points[0] : undefined);
                    return (
                      <g key={point.id}>
                        {next && <g>
                          <rect x={(point.px + next.px) / 2 - 34} y={(point.py + next.py) / 2 - 16} width="68" height="25" rx="12.5" fill="#142528" fillOpacity=".86" />
                          <text x={(point.px + next.px) / 2} y={(point.py + next.py) / 2 + 4} fill="#f2f1df" textAnchor="middle" fontSize="11" fontFamily="IBM Plex Sans Arabic, sans-serif">{meters(distance(point, next))} م</text>
                        </g>}
                        <circle cx={point.px} cy={point.py} r="10" fill="#142528" fillOpacity=".28" stroke="#a9e4bd" strokeWidth="2" />
                        <circle cx={point.px} cy={point.py} r="4.5" fill="#f1a18e" stroke="#fff7e5" strokeWidth="1.5" />
                        <text x={point.px} y={point.py - 16} fill="#f2f1df" textAnchor="middle" fontSize="10" fontFamily="IBM Plex Sans Arabic, sans-serif">{index + 1}</text>
                      </g>
                    );
                  })}
                </svg>
              )}

              {isActive && points.length >= 3 && (
                <div className="absolute bottom-5 left-4 right-4 z-10 flex items-center justify-between gap-3 sm:bottom-6 sm:left-6 sm:right-6">
                  <div className="rounded-2xl border border-white/10 bg-[#142528]/80 px-3.5 py-2.5 text-right text-[#f2f1df] backdrop-blur-md">
                    <div className="mb-0.5 text-[10px] text-[#b9d4c1]">المحيط التقريبي</div>
                    <div className="number-display text-base font-semibold">{meters(perimeter)} <span className="font-sans text-[11px] font-normal text-[#bfd2c5]">م</span></div>
                  </div>
                  {!isClosed ? (
                    <button type="button" onClick={closePolygon} data-testid="button-close-polygon" className="control-button inline-flex items-center gap-2 rounded-2xl bg-[#f1a18e] px-4 py-3 text-xs font-bold text-[#142528] shadow-[0_8px_20px_rgba(20,37,40,.25)]">
                      <Check size={16} strokeWidth={2.5} /> إغلاق الشكل
                    </button>
                  ) : (
                    <div className="inline-flex items-center gap-2 rounded-2xl bg-[#a9e4bd] px-4 py-3 text-xs font-bold text-[#142528]"><Check size={16} strokeWidth={2.5} /> اكتمل القياس</div>
                  )}
                </div>
              )}
            </div>
            {isActive && (
              <div className="mt-3 flex items-center justify-between gap-3 px-1 text-[11px] text-[#607876]">
                <span className="flex items-center gap-1.5"><Target size={13} className="text-[#0b7c78]" /> {isArMode ? 'تحديد أرضي بالواقع المعزز' : 'تحديد يدوي بمعايرة المقياس'}</span>
                <span data-testid="text-selected-points">{points.length} نقاط محددة</span>
              </div>
            )}
          </section>

          <aside className="room-rise room-delay-2 order-2 flex flex-col gap-4 lg:order-2">
            {!isActive ? (
              <div className="instrument-panel rounded-[28px] p-6 sm:p-8">
                <div className="mb-7 flex items-center justify-between">
                  <div className="inline-flex items-center gap-2 rounded-full bg-[#dcece1] px-3 py-1.5 text-[11px] font-semibold text-[#176a64]"><span className="h-1.5 w-1.5 rounded-full bg-[#27a878]" /> دقة بالمتر</div>
                  <span className="font-mono text-[10px] tracking-[.14em] text-[#6f8882]">ROOM / 01</span>
                </div>
                <h1 className="mb-3 font-[var(--app-font-serif)] text-[30px] font-semibold leading-[1.55] tracking-[-.06em] text-[#142528] sm:text-[35px]">اعرف مساحتك<br /><span className="text-[#0b7c78]">قبل أول خطوة.</span></h1>
                <p className="mb-8 max-w-[31rem] text-sm leading-7 text-[#5f7471]">حوّل كاميرا هاتفك إلى أداة قياس هادئة ودقيقة. حدّد زوايا الغرفة، وسنحسب لك المسافة والمساحة في لحظتها.</p>
                <button type="button" onClick={startCamera} disabled={isStarting} data-testid="button-start-camera" className="control-button group flex w-full items-center justify-between rounded-2xl bg-[#142528] px-5 py-4 text-right text-[#f2f1df] shadow-[0_12px_24px_rgba(20,37,40,.16)] hover:bg-[#21484a] disabled:cursor-wait disabled:opacity-70">
                  <span className="flex items-center gap-3">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#a9e4bd] text-[#142528]">{isStarting ? <RefreshCw size={17} className="animate-spin" /> : <Camera size={17} />}</span>
                    <span><span className="block text-sm font-semibold">{isStarting ? 'جاري تشغيل الكاميرا' : 'ابدأ القياس'}</span><span className="mt-0.5 block text-[10px] text-[#b9d4c1]">نحتاج إذنك لمرة واحدة فقط</span></span>
                  </span>
                  <span className="text-xl text-[#a9e4bd]">←</span>
                </button>
                <div className="mt-5 flex items-start gap-2 border-t border-[#d8e3da] pt-4 text-[11px] leading-5 text-[#6a807b]">
                  <LockKeyhole size={14} className="mt-0.5 shrink-0 text-[#0b7c78]" />
                  <span>المعالجة تتم على جهازك. لا يتم حفظ الصور أو إرسالها.</span>
                </div>
              </div>
            ) : (
              <div className="instrument-panel rounded-[28px] p-5 sm:p-6">
                <div className="mb-5 flex items-start justify-between">
                  <div>
                    <div className="mb-1 flex items-center gap-2 text-[11px] font-semibold text-[#0b7c78]"><Ruler size={14} /> لوحة القياس</div>
                    <h2 className="font-[var(--app-font-serif)] text-xl font-semibold text-[#142528]">نتيجة الغرفة</h2>
                  </div>
                  <div className="rounded-xl bg-[#edf4e8] px-2.5 py-2 text-[10px] font-semibold text-[#36705f]">{isClosed ? 'مغلق' : 'قيد التحديد'}</div>
                </div>
                <div className="rounded-2xl bg-[#142528] p-5 text-[#f2f1df]">
                  <div className="mb-2 flex items-center justify-between text-[11px] text-[#b9d4c1]"><span>المساحة الكلية</span><span className="font-mono text-[10px] text-[#8db6a3]">M²</span></div>
                  <div className="number-display text-[48px] font-semibold leading-none text-[#f2f1df]" data-testid="text-total-area">{meters(area)} <span className="font-sans text-sm font-medium tracking-normal text-[#a9e4bd]">م²</span></div>
                  <div className="mt-4 flex items-center gap-2 border-t border-white/10 pt-3 text-[10px] text-[#b7cfc1]"><Info size={13} className="text-[#f1a18e]" /> {isClosed ? 'المساحة محسوبة وفق النقاط التي حددتها' : 'أضف ٣ نقاط على الأقل لإغلاق المساحة'}</div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <div className="rounded-2xl bg-[#edf1e9] p-3"><div className="mb-1 text-[10px] text-[#6b817c]">النقاط</div><div className="text-lg font-semibold text-[#142528]" data-testid="text-point-count">{points.length}</div></div>
                  <div className="rounded-2xl bg-[#edf1e9] p-3"><div className="mb-1 text-[10px] text-[#6b817c]">المحيط</div><div className="text-lg font-semibold text-[#142528]" data-testid="text-perimeter">{meters(perimeter)} <span className="text-[10px] font-normal text-[#6b817c]">م</span></div></div>
                </div>
                <div className="mt-5 border-t border-[#d8e3da] pt-4">
                  <button type="button" onClick={() => setShowScale((value) => !value)} data-testid="button-calibrate" className="control-button flex w-full items-center justify-between rounded-xl px-2 py-2 text-right text-xs font-semibold text-[#486461] hover:bg-[#edf1e9]">
                    <span className="flex items-center gap-2"><Crosshair size={15} className="text-[#ef6f61]" /> معايرة المقياس اليدوي</span><ChevronDown size={15} className={`transition-transform ${showScale ? 'rotate-180' : ''}`} />
                  </button>
                  {showScale && <div className="mt-3 rounded-xl bg-[#edf1e9] p-3"><div className="mb-2 flex justify-between text-[10px] text-[#607876]"><span>حساسية القياس</span><strong className="font-mono text-[#0b7c78]">{scale} px/m</strong></div><input type="range" min="60" max="220" value={scale} onChange={(event) => setScale(Number(event.target.value))} data-testid="input-scale-panel" aria-label="ضبط حساسية القياس" className="range-instrument h-5 w-full cursor-pointer" /><p className="mt-1 text-[10px] leading-5 text-[#6a807b]">استخدم جسماً بطول معروف كمرجع سريع.</p></div>}
                </div>
              </div>
            )}

            <div className="room-rise room-delay-3 rounded-[22px] border border-[#cbdcd4] bg-[#e8f0e8]/70 p-4">
              <div className="flex items-start gap-3">
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#d0e7d7] text-[#267567]"><Info size={17} /></div>
                <div><h3 className="mb-1 text-xs font-semibold text-[#244c49]">كيف تحصل على نتيجة أدق؟</h3><p className="m-0 text-[11px] leading-5 text-[#5d7770]">تحرك ببطء، حافظ على الهاتف موازياً للأرض، واضغط في منتصف كل زاوية.</p></div>
              </div>
            </div>
            {isActive && (
              <button type="button" onClick={() => setShowReset(true)} data-testid="button-reset-measurement" className="control-button flex items-center justify-center gap-2 rounded-xl border border-[#d5dfd6] bg-[#f8f7f1]/70 px-4 py-3 text-xs font-semibold text-[#5f7471] hover:bg-[#fffdf7]"><RotateCcw size={14} /> مسح النقاط وإعادة القياس</button>
            )}
          </aside>
        </div>

        <footer className="mt-5 flex flex-col items-center justify-between gap-2 border-t border-[#d6e0d8] pt-4 text-[10px] text-[#78908a] sm:flex-row">
          <span>مِقياس — قياس بسيط، قرار أوضح</span>
          <span className="flex items-center gap-1.5"><ShieldCheck size={12} /> يعمل محلياً على جهازك</span>
        </footer>
      </div>

      {showReset && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-[#142528]/45 p-4 backdrop-blur-sm">
          <div role="dialog" aria-modal="true" className="room-rise w-full max-w-sm rounded-[26px] border border-[#d8e3da] bg-[#f8f7f1] p-6 text-right shadow-2xl">
            <div className="mb-5 flex items-start justify-between"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[#f9dfd8] text-[#c45c4e]"><RotateCcw size={18} /></div><button type="button" onClick={() => setShowReset(false)} data-testid="button-close-reset-dialog" aria-label="إغلاق" className="grid h-8 w-8 place-items-center rounded-full text-[#6c817d] hover:bg-[#edf1e9]"><X size={17} /></button></div>
            <h2 className="mb-2 font-[var(--app-font-serif)] text-lg font-semibold text-[#142528]">بدء قياس جديد؟</h2>
            <p className="mb-6 text-xs leading-6 text-[#687c78]">سيتم مسح النقاط الحالية والبدء من مساحة فارغة. ستبقى الكاميرا مفتوحة.</p>
            <div className="flex gap-2"><button type="button" onClick={() => setShowReset(false)} data-testid="button-cancel-reset" className="control-button flex-1 rounded-xl border border-[#d5dfd6] px-4 py-3 text-xs font-semibold text-[#5f7471]">إلغاء</button><button type="button" onClick={resetMeasurement} data-testid="button-confirm-reset" className="control-button flex-1 rounded-xl bg-[#142528] px-4 py-3 text-xs font-semibold text-[#f2f1df] hover:bg-[#21484a]">مسح النقاط</button></div>
          </div>
        </div>
      )}
    </main>
  );
}

export default App;
